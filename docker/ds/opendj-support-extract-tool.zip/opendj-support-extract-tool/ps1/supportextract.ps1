
$ToolRoot = Split-Path $PSScriptRoot

. (Join-Path $ToolRoot "/lib/_config.ps1")

$InstanceDir = Split-Path $CONFIG_DIR

$LogsDir = Join-Path $InstanceDir "logs"
$ConfigFile = Join-Path $CONFIG_DIR "config.ldif"
$LoggingPropertiesFile = Join-Path $ToolRoot 'lib/logging.properties'
$JavaBin = Join-Path $JAVA_HOME "/bin/java.exe"

$ClassPath = Join-Path $ToolRoot 'lib/opendj-support-extract-3.0.jar'
$Parameters = '-cp', "$ClassPath", `
"-Dlogs.dir=$LogsDir", "-Dconfig.file=$ConfigFile", `
"-Djava.util.logging.config.file=$LoggingPropertiesFile", `
"-Djava.bin=$JavaBin", `
'com.forgerock.opendj.support.tools.SupportExtract'

echo $Parameters

cd $PSScriptRoot

& $JavaBin $Parameters @args
