

if (! $JAVA_HOME) {
  $JAVA_HOME = (Get-Item -Path Env:JAVA_HOME).value
}

if (! $JAVA_HOME ) {
    echo "JAVA_HOME is not set"
    echo "Either set variable JAVA_HOME or configure it in the System Environment"
    Exit
}

if (! (Test-Path $JAVA_HOME -ErrorAction SilentlyContinue)) {
    echo "JAVA_HOME has an invalid value (Path not found)"
    Exit
}

$JavaBin = Join-Path $JAVA_HOME "bin\java.exe"

if (! (Test-Path $JavaBin)) {
    echo "JAVA_HOME is set to an invalid JDK Home"
    Exit
}

$CLASSPATH = "$PSScriptRoot/lib/i18n-core-1.4.2.jar;$PSScriptRoot/lib/opendj-tools-setup-3.0.jar"
$Parameters = "-cp", $CLASSPATH, 'com.forgerock.opendj.support.tools.Setup'

& $JavaBin $Parameters
